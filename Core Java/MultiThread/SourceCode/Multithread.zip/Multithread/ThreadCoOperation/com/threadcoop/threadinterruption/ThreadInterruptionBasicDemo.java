package com.threadcoop.threadinterruption;

import java.util.concurrent.TimeUnit;

public class ThreadInterruptionBasicDemo {
	public static void main(String[] args) {
		Thread thread = new Thread(new Demo());
		thread.start();

		try {
			TimeUnit.SECONDS.sleep(3);
			thread.interrupt();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Inside main()...");
	}
}

class Demo implements Runnable {
	@Override
	public void run() {
		System.out.println("Inside run()...");
		try {
			TimeUnit.SECONDS.sleep(9);
		} catch (InterruptedException e) {
			System.out.println("Thread is interrupted!!");
		}
		go();

	}

	private void go() {
		System.out.println("Inside go()...");
		more();
	}

	private void more() {
		System.out.println("Inside more()...");

	}
}
package com.multithread.synchronisation;

import java.util.concurrent.TimeUnit;

//Volatile ensures memory visibility only
public class VolatileDemo {
	/**
	 * If we use volatile in banking makeWithdrawal example we will get memory
	 * visibility but still race condition exist, so need to use synchronisation
	 */
	public static volatile boolean stop = false;

	public static void main(String[] args) {
		new Thread(new Runnable() {

			@Override
			public void run() {
				while (!stop) {
					System.out.println("In proccess");
				}
			}
		}).start();
		try {
			//Thread.sleep(1000);
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		stop = true;
		System.out.println("\nTerminated!!");

	}
}

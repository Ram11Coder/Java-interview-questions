package com.multithread.synchronisation;

import java.util.concurrent.atomic.AtomicLong;

class IdGenerator {
	private AtomicLong id = new AtomicLong(1);

	public long getNewId() {
		return id.incrementAndGet();
	}
}

public class AtomicVariableDemo {
	static IdGenerator idObj = new IdGenerator();

	public static void main(String[] args) {
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				System.out.println(idObj.getNewId());
				
			}
		}).start();
		
		
		new Thread(() -> {System.out.println(idObj.getNewId());
		}).start();
		new Thread(() -> {System.out.println(idObj.getNewId());
		}).start();
		new Thread(() -> {System.out.println(idObj.getNewId());
		}).start();
		new Thread(() -> {System.out.println(idObj.getNewId());
		}).start();
	}
}

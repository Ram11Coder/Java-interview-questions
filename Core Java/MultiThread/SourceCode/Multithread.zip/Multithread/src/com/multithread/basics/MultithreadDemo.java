package com.multithread.basics;

/**
 * Creating thread using Thread class and Runnable Interface
 * 
 * @author thulasi
 *
 */
class ThreadDemo extends Thread {

	public void run() {
		System.out.println("Thread " + Thread.currentThread().getId() + " is running");
	};
}

class RunnableDemo implements Runnable {
	@Override
	public void run() {
		System.out.println("Thread " + Thread.currentThread().getId() + " is running");
	}
}

public class MultithreadDemo {

	public static void main(String[] args) {
		int n = 5;
		/*
		 * System.out.println("Thread class Demo"); for (int i = 0; i < n; i++) {
		 * ThreadDemo t = new ThreadDemo(); t.start(); }
		 */
		System.out.println("Runnable Interface Demo");
		for (int i = 0; i < n; i++) {
			Thread t = new Thread(new RunnableDemo());
			t.start();
		}
	}

}
